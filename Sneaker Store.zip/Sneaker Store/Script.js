
document.addEventListener("DOMContentLoaded", function() {

    console.log("Welcome to Sneaker Hub!");

    // =====================================
    // 1. HOMEPAGE: SPECIAL OFFER BUTTON
    // =====================================

    const offerButton = document.getElementById("offerButton");
    const offerMessage = document.getElementById("offerMessage");

    if (offerButton && offerMessage) {

        offerButton.addEventListener("click", function() {

            if (offerMessage.style.display === "none") {
                offerMessage.style.display = "block";
                offerButton.textContent = "Hide Special Offer";
            } else {
                offerMessage.style.display = "none";
                offerButton.textContent = "View Special Offer";
            }

        });
    }


    // =====================================
    // 2. HOMEPAGE: ENLARGE SNEAKER IMAGE
    // =====================================

    const sneakerImage = document.getElementById("sneakerImage");

    if (sneakerImage) {

        sneakerImage.addEventListener("click", function() {
            sneakerImage.classList.toggle("enlarged");
        });

    }


    // =====================================
    // 3. UPDATE COPYRIGHT YEAR
    // =====================================

    const year = document.getElementById("year");

    if (year) {
        year.textContent = new Date().getFullYear();
    }


    // =====================================
    // 4. HOMEPAGE: VIEW PRODUCTS BUTTON
    // =====================================

    const productButton = document.getElementById("productButton");

    if (productButton) {

        productButton.addEventListener("click", function() {
            window.location.href = "products.html";
        });

    }


    // =====================================
    // 5. ERROR MESSAGE FUNCTIONS
    // =====================================

    function showError(input, message) {

        const error = document.getElementById(input.id + "Error");

        if (error) {
            error.textContent = message;
        }

        input.classList.add("input-error");
    }


    function clearError(input) {

        const error = document.getElementById(input.id + "Error");

        if (error) {
            error.textContent = "";
        }

        input.classList.remove("input-error");
    }


    // =====================================
    // 6. VALIDATE NAME, EMAIL AND PHONE
    // =====================================

    function validatePersonalDetails(form) {

        let valid = true;

        const name = form.querySelector("#name");
        const email = form.querySelector("#email");
        const phone = form.querySelector("#phone");

        // NAME VALIDATION

        if (!name || !/^[A-Za-z ]{2,}$/.test(name.value.trim())) {

            if (name) {
                showError(name, "Please enter a valid name using letters only.");
            }

            valid = false;

        } else {
            clearError(name);
        }


        // EMAIL VALIDATION

        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {

            if (email) {
                showError(email, "Please enter a valid email address.");
            }

            valid = false;

        } else {
            clearError(email);
        }


        // PHONE VALIDATION

        if (!phone || !/^[0-9]{10}$/.test(phone.value.trim())) {

            if (phone) {
                showError(phone, "Phone number must contain exactly 10 digits.");
            }

            valid = false;

        } else {
            clearError(phone);
        }

        return valid;
    }


    // =====================================
    // 7. CONTACT US FORM VALIDATION
    // =====================================

    const contactForm = document.getElementById("contactForm");

    if (contactForm) {

        contactForm.addEventListener("submit", function(event) {

            event.preventDefault();

            const valid = validatePersonalDetails(contactForm);

            if (!valid) {
                return;
            }

            const response = document.getElementById("contactResponse");

            if (response) {
                response.textContent =
                    "Thank you! Your contact details have been validated successfully.";
            }

            contactForm.reset();

        });

    }


    // =====================================
    // 8. ENQUIRIES FORM VALIDATION
    // =====================================

    const enquiryForm = document.getElementById("enquiryForm");

    if (enquiryForm) {

        enquiryForm.addEventListener("submit", function(event) {

            event.preventDefault();

            let valid = validatePersonalDetails(enquiryForm);

            const subject = enquiryForm.querySelector("#subject");
            const message = enquiryForm.querySelector("#message");

            // ENQUIRY TYPE VALIDATION

            if (subject && subject.value === "") {

                showError(subject, "Please select an enquiry type.");
                valid = false;

            } else if (subject) {
                clearError(subject);
            }


            // MESSAGE VALIDATION

            if (message && message.value.trim().length < 10) {

                showError(message, "Your enquiry must contain at least 10 characters.");
                valid = false;

            } else if (message) {
                clearError(message);
            }


            if (!valid) {
                return;
            }

            const response = document.getElementById("response");

            if (response) {
                response.textContent =
                    "Thank you! Your enquiry has been validated successfully.";
            }

            enquiryForm.reset();

        });

    }


    // =====================================
    // 9. CLEAR ERRORS WHEN USER TYPES
    // =====================================

    document.querySelectorAll("form input, form select, form textarea")
        .forEach(function(input) {

            input.addEventListener("input", function() {
                clearError(input);
            });

            input.addEventListener("change", function() {
                clearError(input);
            });

        });


    // =====================================
    // 10. SHOPPING CART
    // =====================================

    let cart = [];

    const addButtons = document.querySelectorAll(".add-to-cart");
    const cartItems = document.getElementById("cart-items");
    const totalPrice = document.getElementById("total-price");
    const clearCartButton = document.getElementById("clear-cart");


    if (cartItems && totalPrice && clearCartButton) {

        // ADD PRODUCT TO CART

        addButtons.forEach(function(button) {

            button.addEventListener("click", function() {

                const name = button.dataset.name;
                const price = Number(button.dataset.price);

                const existingProduct = cart.find(function(item) {
                    return item.name === name;
                });

                if (existingProduct) {

                    existingProduct.quantity++;

                } else {

                    cart.push({
                        name: name,
                        price: price,
                        quantity: 1
                    });

                }

                displayCart();

            });

        });


        // DISPLAY CART PRODUCTS

        function displayCart() {

            cartItems.innerHTML = "";

            let total = 0;

            if (cart.length === 0) {
                cartItems.innerHTML = "<p>Your cart is empty.</p>";
            }

            cart.forEach(function(item, index) {

                const itemTotal = item.price * item.quantity;

                total += itemTotal;

                const product = document.createElement("div");

                product.className = "cart-item";

                product.innerHTML = `
                    <p>
                        <strong>${item.name}</strong><br>
                        Price: R${item.price.toLocaleString("en-ZA")}<br>
                        Quantity: ${item.quantity}<br>
                        Subtotal: R${itemTotal.toLocaleString("en-ZA")}
                    </p>
                `;

                // REMOVE BUTTON

                const removeButton = document.createElement("button");

                removeButton.textContent = "Remove";
                removeButton.className = "remove-item";

                removeButton.addEventListener("click", function() {

                    cart.splice(index, 1);

                    displayCart();

                });

                product.appendChild(removeButton);

                cartItems.appendChild(product);

            });


            // CALCULATE TOTAL PRICE

            totalPrice.textContent = "R" + total.toLocaleString("en-ZA", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });

        }


        // CLEAR ENTIRE SHOPPING CART

        clearCartButton.addEventListener("click", function() {

            cart = [];

            displayCart();

        });

        displayCart();

    }

});
